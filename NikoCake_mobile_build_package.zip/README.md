# NikoCake（Android / Nikon 联机拍摄原型）

这是一个**可在 Android Studio 中直接打开的 Java Android 工程**，按 2026 年公开资料中的 Nikon / PixCake 联机工作流设计。当前工程是第一版原型，不把未经测试的机型兼容性描述成“100%支持”。

## 当前实现

- **USB/PTP**：Android USB Host 检测 PTP 相机；建立 PTP Session；尝试自动轮询新文件并下载；提供 Nikon Live View 命令 `StartLiveView / GetLiveViewImg / EndLiveView`；提供拍照命令。
- **Wi‑Fi / 相机热点**：手机端开启被动 FTP Server；显示本机 IP、端口、用户名和密码。尼康相机可按“FTP 服务器”方式把照片直接推送到手机；新文件进入 `incoming`，支持拍摄一张接收一张。
- **自定义滤镜**：导入标准 `.cube` 3D LUT；导入后对收到的 JPEG 自动套用 LUT，并写入 `processed`。
- **中文界面**：主流程全部中文。
- **无需额外云账号**：当前“云创/我的滤镜”部分实现为本地 CUBE 库；没有伪造一个不存在的云端接口。后续可以接入你的真实云端 API。

## 与像素蛋糕公开流程的对应关系

像素蛋糕公开的尼康有线方案要求 USB 数据连接为 `MTP/PTP`，并把 USB 连接优先设为“拍摄”；Android 端还涉及 OTG。它公开的 Z8 无线方案包含“相机连接手机热点/同一 Wi‑Fi”以及 FTP 服务器配置。像素蛋糕的滤镜公开说明中，“我的”滤镜支持导入 **CUBE** 格式。

本工程因此采用：

`USB/PTP → PTP 控制/传图/Live View`

`Wi‑Fi/手机热点 → 手机 FTP Server ← Nikon FTP Client`

`收到 JPEG → 可选 CUBE LUT → 自动保存处理图`

## 重要限制

1. **尚未生成可安装 APK**：当前执行环境没有可用 Android SDK/Gradle Android 构建链，因此无法在这里诚实地声称“已经编译并实机验证 APK”。我已经把完整工程打包给你，打开 Android Studio 后即可构建。
2. **USB Live View 是机型/固件相关能力**。Nikon 的 PTP 扩展命令在不同机型、固件和拍摄模式下可能拒绝；需要你的相机实机验证。
3. **Wi‑Fi FTP 接片与 Wi‑Fi Live View 是两件事**。本版 Wi‑Fi 部分首先实现 PixelCake 文档中最清晰的 FTP 自动接片路线；Wi‑Fi PTP/IP Live View 尚未作为已验证功能写进成品承诺。
4. **CUBE 是 LUT 滤镜，不等同于完整的 AI 修图/云端预设系统**。当前只实现标准 `.cube` 3D LUT。

## 构建

用 Android Studio 打开项目根目录 `NikoCake/`，等待 Gradle 同步，然后运行 `app` 模块。

最低 Android 版本：9.0（API 28）

目标 SDK：35

建议：用 USB-C OTG 数据线直接连接 Nikon 相机；相机设置为 MTP/PTP，并关闭会影响稳定性的 USB 供电选项（具体菜单因机型而不同）。

## Wi‑Fi 使用示例（以 Nikon Z8 的公开流程为参考）

1. 手机开启热点，或手机和相机加入同一 Wi‑Fi。
2. 打开 NikoCake → “开启 Wi‑Fi FTP 接片”。
3. 记下页面显示的 IP/端口/用户名/密码。
4. 在相机网络/FTP 设置里把服务器指向 NikoCake 显示的地址，开启自动传输。
5. 拍照后，照片会自动落到 NikoCake 的 `incoming`；若已导入 CUBE，JPEG 会自动生成处理版。

## 资料来源（公开页面）

- Nikon SnapBridge / 支持机型与功能：https://snapbridge.nikon.com/
- Nikon 官方 SnapBridge 说明：https://imaging.nikon.com/imaging/lineup/software/snapbridge/
- PixCake《联机拍摄——尼康相机》：https://www.pixcakeai.com/guide/170682
- PixCake《Android版有线联机拍摄运用》：https://www.pixcakeai.com/guide/176674
- PixCake《相机/监视器模式》：https://www.pixcakeai.com/guide/225513
- PixCake《色彩调节 / CUBE 滤镜》：https://wiki.pixcakeai.com/guide/9398.html
- libgphoto2 / PTP 与 Nikon Live View 命令参考：https://github.com/gphoto/libgphoto2

## 下一步建议

拿一台具体的 Nikon 机身（优先 Z8）做实机回归，把 USB Live View、拍照、自动下载、RAW/JPEG 选择、缩略图、断线重连和 Wi‑Fi PTP/IP 连接逐项跑通后，再打正式 APK。
