# NikoCake 手机云端编译 APK

本项目包含 GitHub Actions 工作流。上传到 GitHub 后，可以直接在手机浏览器里启动构建，并下载 `app-debug.apk`。

## 手机操作

1. 在 GitHub 新建一个仓库。
2. 将本项目解压后的**所有文件和文件夹**上传到仓库根目录（不要把整个 ZIP 再套一层目录）。
3. 打开仓库的 `Actions` → `Build NikoCake APK`。
4. 点 `Run workflow`（如果已经 push 到 main/master，也会自动开始）。
5. 等待绿色 `Success`。
6. 打开这次运行页面，在底部 `Artifacts` 下载 `NikoCake-debug-apk.zip`。
7. 手机解压后得到 `app-debug.apk`，点击安装。

这是 debug APK，只适合测试。首次安装 Android 可能要求允许当前浏览器/文件管理器“安装未知应用”。
