# Keep simple app build; no custom rules required.
