package com.kaer.nikocake;

import android.graphics.Bitmap;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Minimal .cube 3D LUT reader with trilinear interpolation. */
public final class CubeLut {
    private final int size;
    private final float[] data;
    private final float rMin, rMax, gMin, gMax, bMin, bMax;
    public final String name;

    private CubeLut(String name, int size, float[] data,
                    float rMin, float rMax, float gMin, float gMax, float bMin, float bMax) {
        this.name = name; this.size = size; this.data = data;
        this.rMin = rMin; this.rMax = rMax; this.gMin = gMin; this.gMax = gMax; this.bMin = bMin; this.bMax = bMax;
    }

    public static CubeLut parse(File file) throws IOException {
        int size = -1; float[] mins = {0,0,0}; float[] maxs = {1,1,1};
        ArrayList<float[]> rows = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
                String[] p = line.split("\\s+");
                if (p[0].equalsIgnoreCase("TITLE")) continue;
                if (p[0].equalsIgnoreCase("LUT_3D_SIZE")) {
                    size = Integer.parseInt(p[1]);
                    continue;
                }
                if (p[0].equalsIgnoreCase("DOMAIN_MIN")) {
                    mins[0]=Float.parseFloat(p[1]); mins[1]=Float.parseFloat(p[2]); mins[2]=Float.parseFloat(p[3]);
                    continue;
                }
                if (p[0].equalsIgnoreCase("DOMAIN_MAX")) {
                    maxs[0]=Float.parseFloat(p[1]); maxs[1]=Float.parseFloat(p[2]); maxs[2]=Float.parseFloat(p[3]);
                    continue;
                }
                if (p.length >= 3) {
                    try { rows.add(new float[]{Float.parseFloat(p[0]), Float.parseFloat(p[1]), Float.parseFloat(p[2])}); }
                    catch (NumberFormatException ignored) { }
                }
            }
        }
        if (size < 2) throw new IOException("CUBE缺少有效的 LUT_3D_SIZE");
        if (rows.size() != size*size*size) throw new IOException("CUBE数据数量不正确：" + rows.size());
        float[] d = new float[rows.size()*3];
        for (int i=0;i<rows.size();i++) { d[i*3]=rows.get(i)[0]; d[i*3+1]=rows.get(i)[1]; d[i*3+2]=rows.get(i)[2]; }
        return new CubeLut(file.getName(), size, d, mins[0], maxs[0], mins[1], maxs[1], mins[2], maxs[2]);
    }

    private float[] sample(float x, float y, float z) {
        float fx = clamp((x-rMin)/(rMax-rMin),0,1)*(size-1);
        float fy = clamp((y-gMin)/(gMax-gMin),0,1)*(size-1);
        float fz = clamp((z-bMin)/(bMax-bMin),0,1)*(size-1);
        int x0=(int)Math.floor(fx), y0=(int)Math.floor(fy), z0=(int)Math.floor(fz);
        int x1=Math.min(x0+1,size-1), y1=Math.min(y0+1,size-1), z1=Math.min(z0+1,size-1);
        float dx=fx-x0, dy=fy-y0, dz=fz-z0;
        float[] out = new float[3];
        for (int c=0;c<3;c++) {
            float c000=v(x0,y0,z0,c), c100=v(x1,y0,z0,c), c010=v(x0,y1,z0,c), c110=v(x1,y1,z0,c);
            float c001=v(x0,y0,z1,c), c101=v(x1,y0,z1,c), c011=v(x0,y1,z1,c), c111=v(x1,y1,z1,c);
            float c00=c000+(c100-c000)*dx, c10=c010+(c110-c010)*dx;
            float c01=c001+(c101-c001)*dx, c11=c011+(c111-c011)*dx;
            float c0=c00+(c10-c00)*dy, c1=c01+(c11-c01)*dy;
            out[c]=c0+(c1-c0)*dz;
        }
        return out;
    }
    private float v(int x,int y,int z,int c) { return data[((z*size + y)*size + x)*3+c]; }
    private static float clamp(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}

    public Bitmap apply(Bitmap src, float intensity) {
        intensity = clamp(intensity,0,1);
        Bitmap out = src.copy(Bitmap.Config.ARGB_8888, true);
        int[] px = new int[out.getWidth()*out.getHeight()];
        out.getPixels(px,0,out.getWidth(),0,0,out.getWidth(),out.getHeight());
        for(int i=0;i<px.length;i++){
            int a=(px[i]>>>24)&255, r=(px[i]>>>16)&255, g=(px[i]>>>8)&255, b=px[i]&255;
            float[] q=sample(r/255f,g/255f,b/255f);
            int rr=(int)(255f*(r/255f*(1-intensity)+clamp(q[0],0,1)*intensity)+0.5f);
            int gg=(int)(255f*(g/255f*(1-intensity)+clamp(q[1],0,1)*intensity)+0.5f);
            int bb=(int)(255f*(b/255f*(1-intensity)+clamp(q[2],0,1)*intensity)+0.5f);
            px[i]=(a<<24)|(rr<<16)|(gg<<8)|bb;
        }
        out.setPixels(px,0,out.getWidth(),0,0,out.getWidth(),out.getHeight());
        return out;
    }
}
