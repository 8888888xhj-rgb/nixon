package com.kaer.nikocake;

import android.content.Context;
import android.os.Handler;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * Small passive-mode FTP server for camera upload.
 * Default control port 2121; camera can be configured to use this address/port.
 */
public final class FtpServer {
    public interface Listener {
        void onLog(String s);
        void onFile(File file);
    }
    private final Context ctx; private final Listener listener; private final File root; private final Handler handler;
    private volatile boolean running; private ServerSocket control;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final String user="nikocake", pass="123456";
    private int passivePort = 23000;

    public FtpServer(Context ctx, File root, Listener listener, Handler handler){this.ctx=ctx;this.root=root;this.listener=listener;this.handler=handler;root.mkdirs();}
    public synchronized String start() throws IOException {
        if(running) return localIp(ctx)+":"+control.getLocalPort();
        control = new ServerSocket(2121, 50, InetAddress.getByName("0.0.0.0")); running=true;
        pool.execute(() -> acceptLoop());
        return localIp(ctx)+":"+control.getLocalPort();
    }
    public synchronized void stop(){ running=false; try{if(control!=null)control.close();}catch(Exception ignored){} }
    public boolean isRunning(){return running;}
    public String credentials(){return "用户名="+user+"  密码="+pass+"  PASV端口范围=23000-23049";}

    private void acceptLoop(){while(running){try{Socket s=control.accept(); pool.execute(() -> session(s));}catch(IOException e){if(running) log("FTP监听异常："+e.getMessage());}}}
    private void session(Socket s){
        ServerSocket pasv=null;
        try(Socket sock=s; BufferedReader br=new BufferedReader(new InputStreamReader(sock.getInputStream())); BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(sock.getOutputStream()))){
            send(bw,"220 NikoCake FTP ready"); String cwd="/"; boolean auth=false;
            while(true){String line=br.readLine(); if(line==null)break; String[] pp=line.split(" ",2); String cmd=pp[0].toUpperCase(Locale.US); String arg=pp.length>1?pp[1]:"";
                switch(cmd){
                    case "USER": send(bw,"331 Password required"); break;
                    case "PASS": auth=arg.equals(pass); send(bw,auth?"230 Login successful":"530 Login incorrect"); break;
                    case "SYST": send(bw,"215 UNIX Type: L8"); break;
                    case "FEAT": send(bw,"211-Features\r\n PASV\r\n UTF8\r\n211 End"); break;
                    case "OPTS": send(bw,"200 OK"); break;
                    case "TYPE": send(bw,"200 Type set"); break;
                    case "PWD": send(bw,"257 \"/\" is current directory"); break;
                    case "CWD": cwd="/"; send(bw,"250 OK"); break;
                    case "NOOP": send(bw,"200 OK"); break;
                    case "PASV":
                        if(pasv!=null)try{pasv.close();}catch(Exception ignored){}
                        pasv=new ServerSocket(findFreePassivePort(),1,InetAddress.getByName("0.0.0.0"));
                        String ip=localIp(ctx); String[] ip4=ip.split("\\."); int p=pasv.getLocalPort();
                        send(bw,"227 Entering Passive Mode ("+ip4[0]+","+ip4[1]+","+ip4[2]+","+ip4[3]+","+(p/256)+","+(p%256)+")"); break;
                    case "LIST": send(bw,"150 Opening data connection"); if(pasv!=null){try(Socket ds=pasv.accept(); BufferedWriter dw=new BufferedWriter(new OutputStreamWriter(ds.getOutputStream()))){dw.write("-rw-r--r-- 1 nikocake nikocake 0 Jan 01 00:00 placeholder.jpg\r\n");}pasv.close();pasv=null;} send(bw,"226 Transfer complete"); break;
                    case "STOR":
                        if(!auth){send(bw,"530 Not logged in");break;} if(pasv==null){send(bw,"425 Use PASV first");break;}
                        File f=new File(root,safeName(arg)); send(bw,"150 Opening data connection");
                        try(Socket ds=pasv.accept(); OutputStream out=new BufferedOutputStream(new FileOutputStream(f))){byte[] buf=new byte[32768];int n;while((n=ds.getInputStream().read(buf))!=-1)out.write(buf,0,n);} catch(Exception e){log("STOR失败："+e.getMessage());}
                        pasv.close();pasv=null; send(bw,"226 Transfer complete");
                        handler.post(() -> listener.onFile(f)); break;
                    case "QUIT": send(bw,"221 Goodbye"); return;
                    default: send(bw,"502 Command not implemented");
                }
            }
        }catch(Exception e){log("FTP会话结束："+e.getMessage());}finally{try{if(pasv!=null)pasv.close();}catch(Exception ignored){}}
    }
    private int findFreePassivePort(){for(int p=passivePort;p<passivePort+50;p++){try(ServerSocket ss=new ServerSocket(p)){passivePort=p+1;return p;}catch(IOException ignored){}}return 23000;}
    private String safeName(String s){s=s.replace("\\","/"); int i=s.lastIndexOf('/'); if(i>=0)s=s.substring(i+1); if(s.isEmpty())s="camera_"+System.currentTimeMillis()+".jpg"; return s.replaceAll("[^a-zA-Z0-9._-]","_");}
    private void send(Writer w,String s)throws IOException{w.write(s+"\r\n");w.flush();}
    private void log(String s){handler.post(() -> listener.onLog(s));}
    public static String localIp(Context ctx){try{
        for(Enumeration<NetworkInterface> en=NetworkInterface.getNetworkInterfaces();en.hasMoreElements();){NetworkInterface ni=en.nextElement(); for(Enumeration<InetAddress> ea=ni.getInetAddresses();ea.hasMoreElements();){InetAddress a=ea.nextElement(); if(!a.isLoopbackAddress() && a instanceof Inet4Address){String h=a.getHostAddress(); if(!h.startsWith("127."))return h;}}}
    }catch(Exception ignored){} return "0.0.0.0";}
}
