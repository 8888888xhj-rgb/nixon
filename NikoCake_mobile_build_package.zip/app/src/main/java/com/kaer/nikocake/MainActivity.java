package com.kaer.nikocake;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.net.Uri;
import android.provider.Settings;
import android.hardware.usb.*;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity implements FtpServer.Listener, PtpUsbClient.Listener {
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout root, logBox;
    private TextView status, ftpInfo;
    private ImageView preview;
    private FtpServer ftp;
    private PtpUsbClient ptp;
    private CubeLut activeLut;
    private ExecutorService work=Executors.newSingleThreadExecutor();
    private final BroadcastReceiver usbReceiver = new BroadcastReceiver(){
        @Override public void onReceive(Context c, Intent i){
            if("com.kaer.nikocake.USB_PERMISSION".equals(i.getAction())){
                UsbDevice d=i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                boolean ok=i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED,false);
                if(ok&&d!=null) connectDevice(d); else log("USB权限未授予");
            } else if(UsbManager.ACTION_USB_DEVICE_DETACHED.equals(i.getAction())) { log("USB设备已拔出"); }
        }
    };

    @Override protected void onCreate(Bundle b){super.onCreate(b); buildUi(); registerUsb(); detectUsb();}
    @Override protected void onDestroy(){super.onDestroy();try{unregisterReceiver(usbReceiver);}catch(Exception ignored){} if(ftp!=null)ftp.stop();if(ptp!=null)ptp.close();work.shutdownNow();}

    private void buildUi(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,28,28,24); root.setBackgroundColor(Color.WHITE);
        ScrollView scroll=new ScrollView(this); LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
        TextView title=t("NikoCake · 尼康联机拍摄",24,true); body.addView(title,lp());
        TextView sub=t("USB / 相机热点 / Wi‑Fi FTP / 实时监看 / 自动接片 / CUBE滤镜",14,false);body.addView(sub,lp(0,8,0,14));
        status=t("状态：等待连接",15,true);body.addView(status,lp());
        ftpInfo=t("Wi‑Fi FTP：未启动",14,false);body.addView(ftpInfo,lp(0,6,0,8));

        body.addView(btn("检测USB相机",v->detectUsb()),lp(0,4,0,4));
        body.addView(btn("开启Wi‑Fi FTP接片",v->startFtp()),lp(0,4,0,4));
        body.addView(btn("关闭Wi‑Fi FTP",v->{if(ftp!=null){ftp.stop();ftp=null;ftpInfo.setText("Wi‑Fi FTP：已关闭");}}),lp(0,4,0,4));
        body.addView(btn("导入CUBE自定义滤镜",v->pickCube()),lp(0,4,0,4));
        body.addView(btn("开启实时监看（USB）",v->{if(ptp!=null)ptp.startLiveView();else log("请先连接USB相机");}),lp(0,4,0,4));
        body.addView(btn("停止实时监看",v->{if(ptp!=null)ptp.stopLiveView();}),lp(0,4,0,4));
        body.addView(btn("拍一张并自动接收",v->{if(ptp!=null)ptp.takePhoto();else log("USB模式下请先连接相机；Wi‑Fi FTP模式可直接用相机快门拍摄");}),lp(0,4,0,4));

        preview=new ImageView(this);preview.setAdjustViewBounds(true);preview.setScaleType(ImageView.ScaleType.CENTER_INSIDE);body.addView(preview,lp(0,12,0,8));
        TextView hint=t("尼康Z8/Z6II等：USB端请设为MTP/PTP、USB连接优先选择拍摄；无线端可让相机连手机热点，并把FTP服务器设置为本页面显示的地址、端口、用户名和密码。",13,false);hint.setPadding(0,10,0,10);body.addView(hint,lp());
        TextView logTitle=t("运行日志",16,true);body.addView(logTitle,lp(0,8,0,4));
        logBox=new LinearLayout(this);logBox.setOrientation(LinearLayout.VERTICAL);body.addView(logBox,lp());
        scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView foot=t("NikoCake 0.1.0 · 原型版",12,false);foot.setGravity(Gravity.CENTER);root.addView(foot,lp(0,10,0,0));setContentView(root);
    }
    private TextView t(String s,int sp,boolean bold){TextView x=new TextView(this);x.setText(s);x.setTextSize(sp);x.setTextColor(Color.rgb(25,25,25));if(bold)x.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return x;}
    private Button btn(String s,View.OnClickListener l){Button b=new Button(this);b.setText(s);b.setOnClickListener(l);return b;}
    private LinearLayout.LayoutParams lp(){return new LinearLayout.LayoutParams(-1,-2);}
    private LinearLayout.LayoutParams lp(int l,int t,int r,int b){LinearLayout.LayoutParams p=lp();p.setMargins(l,t,r,b);return p;}

    private void registerUsb(){IntentFilter f=new IntentFilter();f.addAction("com.kaer.nikocake.USB_PERMISSION");f.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);registerReceiver(usbReceiver,f, Context.RECEIVER_NOT_EXPORTED);}
    private UsbManager getUsb(){return (UsbManager)getSystemService(Context.USB_SERVICE);}
    private void detectUsb(){UsbManager um=getUsb();if(um==null)return;Map<String,UsbDevice> devices=um.getDeviceList();if(devices.isEmpty()){log("未发现USB设备");return;}for(UsbDevice d:devices.values()){if(isLikelyCamera(d)){log("发现相机："+(d.getProductName()==null?"USB Camera":d.getProductName()));requestPermission(d);return;}}log("发现USB设备，但没有识别为PTP相机");}
    private boolean isLikelyCamera(UsbDevice d){for(int i=0;i<d.getInterfaceCount();i++){UsbInterface it=d.getInterface(i);if(it.getInterfaceClass()==UsbConstants.USB_CLASS_STILL_IMAGE||it.getInterfaceClass()==6)return true;}return false;}
    private void requestPermission(UsbDevice d){PendingIntent pi=PendingIntent.getBroadcast(this,100, new Intent("com.kaer.nikocake.USB_PERMISSION"), PendingIntent.FLAG_IMMUTABLE);getUsb().requestPermission(d,pi);}
    private void connectDevice(UsbDevice d){if(ptp!=null)ptp.close();ptp=new PtpUsbClient(this,d,this,ui);ptp.connectAsync();}

    private void startFtp(){try{if(ftp!=null&&ftp.isRunning()){log("FTP已经运行");return;}File dir=new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES),"incoming");ftp=new FtpServer(this,dir,this,ui);String addr=ftp.start();ftpInfo.setText("Wi‑Fi FTP："+addr+"\n"+ftp.credentials());log("FTP已启动。把尼康相机连接到本机热点/同一Wi‑Fi后，按PixelCake式FTP流程填入服务器信息。");}catch(Exception e){log("FTP启动失败："+e.getMessage());}}

    private void pickCube(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/octet-stream");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,false);i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,7);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==7&&c==RESULT_OK&&d!=null&&d.getData()!=null){Uri u=d.getData();work.execute(()->{try{File dir=new File(getExternalFilesDir(null),"filters");dir.mkdirs();File dst=new File(dir,"filter_"+System.currentTimeMillis()+".cube");try(InputStream in=getContentResolver().openInputStream(u);OutputStream out=new FileOutputStream(dst)){byte[] buf=new byte[16384];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);}activeLut=CubeLut.parse(dst);ui.post(()->log("已导入滤镜："+activeLut.name+"，拍摄后JPEG将自动套用"););}catch(Exception e){ui.post(()->log("CUBE导入失败："+e.getMessage()));}});}}

    @Override public void onFile(File file){
        log("收到："+file.getName());
        work.execute(()->processIncoming(file));
    }
    private void processIncoming(File f){
        if(activeLut==null)return;
        String n=f.getName().toLowerCase(Locale.US); if(!n.endsWith(".jpg")&&!n.endsWith(".jpeg"))return;
        try{Bitmap b=BitmapFactory.decodeFile(f.getAbsolutePath());if(b==null)return;Bitmap p=activeLut.apply(b,1f);File outDir=new File(f.getParentFile(),"processed");outDir.mkdirs();File out=new File(outDir,"LUT_"+f.getName());try(FileOutputStream fos=new FileOutputStream(out)){p.compress(Bitmap.CompressFormat.JPEG,95,fos);}p.recycle();ui.post(()->log("已自动套用滤镜："+out.getName()));
            Bitmap view=BitmapFactory.decodeFile(out.getAbsolutePath());if(view!=null)ui.post(()->preview.setImageBitmap(view));
        }catch(Exception e){log("自动套滤镜失败："+e.getMessage());}
    }

    @Override public void onStatus(String s){status.setText("状态："+s);log(s);}
    @Override public void onLiveFrame(Bitmap b){preview.setImageBitmap(b);}
    @Override public void onObject(File f){log("USB收到："+f.getName());if(activeLut!=null)processIncoming(f);}
    @Override public void onLog(String s){log(s);}
    private void log(String s){if(logBox==null)return;ui.post(()->{TextView x=t("• "+s,12,false);logBox.addView(x,0,new LinearLayout.LayoutParams(-1,-2));while(logBox.getChildCount()>40)logBox.removeViewAt(logBox.getChildCount()-1);});}
}
