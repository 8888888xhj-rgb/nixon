package com.kaer.nikocake;

import android.content.Context;
import android.hardware.usb.*;
import android.os.Handler;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.io.*;
import java.nio.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * Minimal Nikon/PTP USB client. It implements the common PTP commands plus
 * Nikon's documented/reverse-engineered live-view operation codes.
 * This is intentionally small and model-agnostic; camera firmware can still
 * reject operations that it does not expose.
 */
public final class PtpUsbClient {
    public interface Listener { void onStatus(String s); void onLiveFrame(Bitmap b); void onObject(File f); }
    private static final int TYPE_COMMAND=1, TYPE_DATA=2, TYPE_RESPONSE=3;
    private static final int OK=0x2001;
    private static final int OC_OpenSession=0x1002, OC_GetDeviceInfo=0x1001, OC_GetObjectHandles=0x1007, OC_GetObject=0x1009, OC_InitiateCapture=0x100E;
    private static final int N_StartLiveView=0x9201, N_EndLiveView=0x9202, N_GetLiveViewImg=0x9203;
    private final UsbDevice device; private final UsbManager usb; private final Listener listener; private final Handler ui;
    private UsbDeviceConnection conn; private UsbEndpoint in,out; private int tid=1; private volatile boolean live;
    private ExecutorService exec=Executors.newSingleThreadExecutor();
    private Set<Long> seen = new HashSet<>();

    public PtpUsbClient(Context c, UsbDevice d, Listener l, Handler h){device=d;usb=(UsbManager)c.getSystemService(Context.USB_SERVICE);listener=l;ui=h;}
    public void close(){live=false; if(exec!=null)exec.shutdownNow(); if(conn!=null)try{conn.close();}catch(Exception ignored){} }
    public void connectAsync(){exec.execute(() -> {
        try{if(!open())throw new IOException("无法打开USB接口"); tx(OC_OpenSession,new int[]{1},false); ui.post(() -> listener.onStatus("USB/PTP连接成功："+device.getProductName())); seedHandles(); pollLoop();}
        catch(Exception e){ui.post(() -> listener.onStatus("USB连接失败："+e.getMessage()));}
    });}
    public void takePhoto(){exec.execute(() -> {try{tx(OC_InitiateCapture,new int[]{0,0},false);ui.post(() -> listener.onStatus("已发送拍照命令"));}catch(Exception e){ui.post(() -> listener.onStatus("拍照失败："+e.getMessage()));}});}
    public void startLiveView(){exec.execute(() -> {try{tx(N_StartLiveView,new int[]{},false);live=true;ui.post(() -> listener.onStatus("实时监看已开启"));while(live){byte[] data=tx(N_GetLiveViewImg,new int[]{},true);byte[] jpeg=findJpeg(data);if(jpeg!=null){Bitmap b=BitmapFactory.decodeByteArray(jpeg,0,jpeg.length);if(b!=null)ui.post(() -> listener.onLiveFrame(b));}Thread.sleep(80);}tx(N_EndLiveView,new int[]{},false);}catch(Exception e){ui.post(() -> listener.onStatus("实时监看失败："+e.getMessage()));}});}
    public void stopLiveView(){live=false;}

    private boolean open(){if(!usb.hasPermission(device))return false;conn=usb.openDevice(device);if(conn==null)return false;
        UsbInterface ptp=null; for(int i=0;i<device.getInterfaceCount();i++){UsbInterface it=device.getInterface(i); if(it.getInterfaceClass()==UsbConstants.USB_CLASS_STILL_IMAGE || it.getInterfaceClass()==6){ptp=it;break;}}
        if(ptp==null && device.getInterfaceCount()>0)ptp=device.getInterface(0); if(!conn.claimInterface(ptp,true))return false;
        for(int i=0;i<ptp.getEndpointCount();i++){UsbEndpoint e=ptp.getEndpoint(i); if(e.getType()==UsbConstants.USB_ENDPOINT_XFER_BULK){if(e.getDirection()==UsbConstants.USB_DIR_IN)in=e;else out=e;}}
        return in!=null&&out!=null;
    }

    private byte[] tx(int code,int[] params,boolean wantData)throws IOException{
        int id=tid++; ByteBuffer c=ByteBuffer.allocate(12+4*(params==null?0:params.length)).order(ByteOrder.LITTLE_ENDIAN); c.putInt(c.capacity());c.putShort((short)TYPE_COMMAND);c.putShort((short)code);c.putInt(id);if(params!=null)for(int p:params)c.putInt(p);bulkOut(c.array());
        if(wantData){PtpContainer d=readContainer(); if(d.type!=TYPE_DATA)throw new IOException("PTP数据包异常"); PtpContainer r=readContainer();check(r,code);return d.payload;}
        PtpContainer r=readContainer();check(r,code);return r.payload;
    }
    private void check(PtpContainer r,int code)throws IOException{if(r.type!=TYPE_RESPONSE)throw new IOException("PTP响应包异常 code="+Integer.toHexString(code)); if(r.code!=OK)throw new IOException("PTP响应错误 0x"+Integer.toHexString(r.code));}
    private void bulkOut(byte[] bytes)throws IOException{int off=0;while(off<bytes.length){int n=conn.bulkTransfer(out,bytes,off,bytes.length-off,5000);if(n<=0)throw new IOException("USB发送失败");off+=n;}}
    private PtpContainer readContainer()throws IOException{byte[] head=readN(12);ByteBuffer b=ByteBuffer.wrap(head).order(ByteOrder.LITTLE_ENDIAN);int len=b.getInt();short type=b.getShort();int code=Short.toUnsignedInt(b.getShort());int id=b.getInt();if(len<12||len>64*1024*1024)throw new IOException("非法PTP长度"+len);byte[] payload=readN(len-12);return new PtpContainer(len,Short.toUnsignedInt(type),code,id,payload);}
    private byte[] readN(int want)throws IOException{byte[] all=new byte[want];int off=0;while(off<want){byte[] buf=new byte[Math.min(16384,want-off)];int n=conn.bulkTransfer(in,buf,buf.length,5000);if(n<=0)throw new IOException("USB接收失败");System.arraycopy(buf,0,all,off,n);off+=n;}return all;}

    private void seedHandles()throws IOException{seen.clear();seen.addAll(listHandles());}
    private void pollLoop(){long last=System.currentTimeMillis();while(!Thread.currentThread().isInterrupted()){try{Set<Long> now=listHandles();for(Long h:now)if(!seen.contains(h)){seen.add(h);byte[] data=tx(OC_GetObject,new int[]{h.intValue()},true);File f=saveObject(data);if(f!=null)ui.post(() -> listener.onObject(f));}if(now.size()>5000 && System.currentTimeMillis()-last>5000){last=System.currentTimeMillis();seen.clear();seen.addAll(now);}Thread.sleep(1000);}catch(Exception e){ui.post(() -> listener.onStatus("自动接收中断："+e.getMessage()));break;}}}
    private Set<Long> listHandles()throws IOException{byte[] data=tx(OC_GetObjectHandles,new int[]{0,0,0},true);ByteBuffer b=ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);long n=Integer.toUnsignedLong(b.getInt());Set<Long>s=new HashSet<>();for(long i=0;i<n&&b.remaining()>=4;i++)s.add(Integer.toUnsignedLong(b.getInt()));return s;}
    private File saveObject(byte[] d)throws IOException{if(d==null||d.length==0)return null;String ext=".bin";if(d.length>4&&d[0]==(byte)0xFF&&d[1]==(byte)0xD8)ext=".jpg";else if(d.length>4 && ((d[0]=='I'&&d[1]=='I')||(d[0]=='M'&&d[1]=='M')))ext=".nef";File dir=new File(new java.io.File(android.os.Environment.getExternalStorageDirectory(),"Android/data/com.kaer.nikocake/files/Pictures"),"NikoCake");dir.mkdirs();File f=new File(dir,"IMG_"+System.currentTimeMillis()+ext);try(FileOutputStream o=new FileOutputStream(f)){o.write(d);}return f;}
    private static byte[] findJpeg(byte[] d){for(int i=0;i<d.length-1;i++)if((d[i]&255)==0xFF&&(d[i+1]&255)==0xD8){for(int j=d.length-1;j>i+1;j--)if((d[j-1]&255)==0xFF&&(d[j]&255)==0xD9)return Arrays.copyOfRange(d,i,j+1);}return null;}
    private static final class PtpContainer{final int len,type,code,id;final byte[]payload;PtpContainer(int l,int t,int c,int i,byte[]p){len=l;type=t;code=c;id=i;payload=p;}}
}
